<?php get_header(); ?>
<?php 
$my_post = wp_get_post_categories( $post->ID, array('fields' => 'all') ); 
$image_parent_cat = get_term_meta($my_post[0]->term_taxonomy_id, 'id-cat-images', true);
?>
        <div class="main_bg " style="background-image: url(<?php echo wp_get_attachment_image_url( $image_parent_cat, 'full'); ?>)">
            <div class="container bg_content">
              <div class="row">
                  <div class="col-12">
                      <h1><span class="yellow"><?php echo $my_post[0]->name; ?></span></h1>
                  </div>
              </div>
            </div>
            <div class="icon_top">
              <div class="container ">
                <div class="social__icon-top">
                  <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/vk.png" alt="VK"></a>
                  <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/youtube.png" alt="youtube"></a>
                  <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/instagram.png" alt="instagram"></a>
                </div>
                <div class="bag_top">
                    <img src="<?php bloginfo('template_url'); ?>/images/icons_logo/shopping-cart.png" alt="">
                    <span class="price_box">(<span>0</span>)</span>
                </div>
              </div>
            </div>
          </div>
   <!-- get_the_post_thumbnail_url( '', 'large' ) -->
        <section class="news_item">
          <div class="container">
            <div class="row ">
              <div class="col-12">
                <div class="nav_menu">
                  <?php if (function_exists('kama_breadcrumbs')) kama_breadcrumbs(); ?>
                </div>
              </div>
            </div>
            <div class="col-12">
              <h2>
                <?php echo $post->post_title; ?>
              </h2>
            </div>
            <div class="col-2 offset-2">
              <?php echo get_the_date('j F Y', $post->ID); ?>
            </div>
            <div class="cart_news col-8 offset-2">
                <?php echo get_the_post_thumbnail('', 'full'); ?>
            </div>

              <div class="news_content col-8 offset-2">
                <?php echo $post->post_content; ?>
              </div>  

              </div>
            </div>
          </div>
               
          </div>
        </section>
        <?php get_template_part('inc/consultation'); ?>
        <section class="discription_cart">
          <div class="container">
            <div class="row">
              <div class="col-12">
                <?php echo $my_post[1]->description; /*var_dump($my_post);*/ ?>
              </div>
            </div>
          </div>
        </section>
<?php wp_reset_postdata(); ?>
<?php get_footer(); ?>