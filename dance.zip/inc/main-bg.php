		<div class="top-carousel-wrapper">
        <div class="carousel top_carousel">
            <div class="carousel-cell">

                <img src="<?php bloginfo('template_url'); ?>/images/bgImage/main_katalog_bg.jpg" alt="">

                <div class="overlay_block"></div>

                <div class="slider__content">
                <h1><span class="yellow">Спец</span>эффекты</h1>
                <div class="main_bg-text"><span class="yellow">Профессиональные спецэффекты для мероприятий и праздников</span></div>
                <a href="" class="btn btn__white">Подробнее</a>
                </div>

            </div>
            <div class="carousel-cell">

                <img src="<?php bloginfo('template_url'); ?>/images/bgImage/main_katalog_bg.jpg" alt="">

                <div class="overlay_block"></div>

                <div class="slider__content">
                <h2><span class="yellow">Спец</span>эффекты</h2>
                <div class="main_bg-text"><span class="yellow">Профессиональные спецэффекты для мероприятий и праздников</span></div>
                <a href="" class="btn btn__white">Подробнее</a>
                </div>

            </div>
            <div class="carousel-cell">

                <img src="<?php bloginfo('template_url'); ?>/images/bgImage/main_katalog_bg.jpg" alt="">

                <div class="overlay_block"></div>

                <div class="slider__content">
                    <h2><span class="yellow">Спец</span>эффекты</h2>
                    <div class="main_bg-text"><span class="yellow">Профессиональные спецэффекты для мероприятий и праздников</span></div>
                    <a href="" class="btn btn__white">Подробнее</a>
                </div>
                
            </div>
        </div>
        <div class="icon_top">
            <div class="container clearfix">
                <div class="social__icon-top">
                    <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/vk.png" alt="VK"></a>
                    <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/youtube.png" alt="youtube"></a>
                    <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/instagram.png" alt="instagram"></a>
                </div>
                <div class="bag_top">
                    <img src="<?php bloginfo('template_url'); ?>/images/icons_logo/shopping-cart.png" alt="">
                    <span class="price_box">(<span>0</span>)</span>
                </div>
            </div>
        </div>
        <div class="icon_top-mouse">
            <a href=""><img src="<?php bloginfo('template_url'); ?>/images/icons_logo/mouse_top.png" alt=""></a>
        </div>
    </div>
