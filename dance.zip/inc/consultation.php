        <section class="consultation">
          <div class="overlay_block"></div>
          <div class="form_group">
            <div class="row">
              <div class="col-12">
                <h2>Консультация со специалистом</h2>
              </div>
            </div>
            <div class="row">
              <form action="#" class="form">
                <div class="input_block">
                  <div class="input_wrap">
                      <input type="text" name="name">
                      <label for="name">Имя:</label>
                  </div>
                  <div class="input_wrap">
                      <input type="text" name="tel">
                      <label for="tel">Телефон:</label>
                  </div>
                </div>
                <div class="btn_group">
                  <button type="submit">Заказать звонок</button>
                  <span>или</span>
                  <button type="submit">Задать вопрос онлайн</button>
                </div>
              </form>
            </div>
          </div>
        </section>