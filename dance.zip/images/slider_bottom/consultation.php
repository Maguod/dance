<!-- consultation -->
<section class="consultation">
    <div class="container consultation_content">
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="text-center">Консультация со специалистом</h2>
                </div>
                <div class="col-xs-12">
                    <div class="input_box">
                        <?php echo do_shortcode('[dhvc_form id="109"]'); ?>
                    </div>
                    <div class="btn_group">
                        <span>или</span>
                        <button type="submit">Задать вопрос онлайн</button>
                    </div>
                </div>
            </div>
    </div> 
</section>
<!-- consultation end -->